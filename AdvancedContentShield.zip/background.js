// background script placeholder
