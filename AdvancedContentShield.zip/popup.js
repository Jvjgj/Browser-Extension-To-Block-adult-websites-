// popup logic placeholder
